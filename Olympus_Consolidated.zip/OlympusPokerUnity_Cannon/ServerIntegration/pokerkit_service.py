"""
FastAPI microservice for evaluating Texas Hold’em hands using PokerKit.

This service exposes a single endpoint (`/api/v1/holdem/equity`) that
accepts hero and villain hole cards (as two‑character strings like "As" for
ace of spades) and an optional community board.  It returns the winner
probabilities for a single run of the game.  For more advanced use cases
(multiple villains, multi‑runout equity, etc.) you can extend this file.
"""

from __future__ import annotations

from typing import List, Dict

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, validator

try:
    # Importing PokerKit requires Python >=3.11
    from pokerkit import StandardHighHand
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "PokerKit is not installed. Install it with `pip install pokerkit`."
    ) from exc


class EquityRequest(BaseModel):
    """Request model for hold’em equity calculation.

    * hero: exactly two hole cards (e.g. ["Ah", "Kd"])
    * villain: exactly two hole cards for the opponent
    * board: zero to five community cards (optional)
    """

    hero: List[str] = Field(..., description="Hero hole cards (two cards)")
    villain: List[str] = Field(..., description="Villain hole cards (two cards)")
    board: List[str] = Field(default_factory=list, description="Community cards")

    @validator("hero")
    def check_hero_len(cls, v: List[str]) -> List[str]:  # noqa: D401
        """Ensure hero has exactly two cards."""
        if len(v) != 2:
            raise ValueError("Hero must have exactly two cards")
        return v

    @validator("villain")
    def check_villain_len(cls, v: List[str]) -> List[str]:  # noqa: D401
        """Ensure villain has exactly two cards."""
        if len(v) != 2:
            raise ValueError("Villain must have exactly two cards")
        return v

    @validator("board")
    def check_board_len(cls, v: List[str]) -> List[str]:  # noqa: D401
        """Ensure board does not exceed five cards."""
        if len(v) > 5:
            raise ValueError("Board cannot have more than 5 cards")
        return v


app = FastAPI(title="PokerKit Equity Service", version="0.1.0")


@app.post("/api/v1/holdem/equity")
def holdem_equity(req: EquityRequest) -> Dict[str, float]:
    """Compute a simple equity result for one hero and one villain.

    The evaluation is deterministic: it compares the hero’s best five‑card hand
    to the villain’s and returns a dictionary with probabilities for hero
    win, villain win, and tie.  This does not perform simulation; it
    evaluates the hands given the current board.

    Args:
        req: JSON body containing hero and villain hole cards and optional
            board.

    Returns:
        A dictionary with keys `hero_win`, `villain_win`, and `tie` and
        probabilities that sum to 1.0.

    Raises:
        HTTPException: if duplicate cards are detected.
    """

    all_cards = req.hero + req.villain + req.board
    # Normalize card strings to uppercase for evaluation
    normalized = [card.strip().upper() for card in all_cards]
    # Check for duplicates
    if len(set(normalized)) != len(normalized):
        raise HTTPException(status_code=400, detail="Duplicate cards detected")

    # Evaluate hero and villain hands using PokerKit’s StandardHighHand
    try:
        hero_hand = StandardHighHand.from_game(req.hero, req.board)
        villain_hand = StandardHighHand.from_game(req.villain, req.board)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid cards: {exc}") from exc

    hero_rank = hero_hand.evaluate()
    villain_rank = villain_hand.evaluate()
    if hero_rank < villain_rank:
        return {"hero_win": 1.0, "villain_win": 0.0, "tie": 0.0}
    if hero_rank > villain_rank:
        return {"hero_win": 0.0, "villain_win": 1.0, "tie": 0.0}
    return {"hero_win": 0.0, "villain_win": 0.0, "tie": 1.0}
