﻿from pydantic import BaseModel

class PrometheusRequest(BaseModel):
    player: str
    variant: str

def validate_request(data: dict) -> PrometheusRequest:
    return PrometheusRequest(**data)
