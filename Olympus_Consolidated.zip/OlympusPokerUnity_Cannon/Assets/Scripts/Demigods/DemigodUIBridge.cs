using UnityEngine;
using Olympus.Gods;

namespace Olympus.Demigods
{
    /// <summary>
    /// Demonstration demigod that listens for result submissions from the
    /// gameplay and logs them.  In a real game this would update the
    /// user interface, play animations, etc.
    /// </summary>
    public class DemigodUIBridge : MonoBehaviour, Platform.IPlatformAdapter
    {
        private void Awake()
        {
            // Register this demigod as the platform adapter.  In a real
            // integration you would register a Skillz adapter instead.
            Hermes.RegisterAdapter(this);
        }

        private void OnDestroy()
        {
            Hermes.UnregisterAdapter();
        }

        public void OnMatchReady(string modeId)
        {
            Debug.Log($"Match ready: {modeId}");
        }

        public void SubmitResult(int score)
        {
            Debug.Log($"Match result submitted: {score}");
        }

        public void OnError(string message)
        {
            Debug.LogError($"Error: {message}");
        }
    }
}