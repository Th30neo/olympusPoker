using System;
using System.Collections.Generic;
using UnityEngine;

namespace Olympus.Libraries
{
    /// <summary>
    /// Definitions for objects loaded from JSON libraries.  These maps
    /// correspond to the JSON files stored in Assets/Resources/Libraries.
    /// </summary>
    [Serializable]
    public class ActionDef
    {
        public string id;
        public string label;
    }

    [Serializable]
    public class BettingStyleDef
    {
        public string id;
        public string label;
    }

    [Serializable]
    public class DeckDef
    {
        public string id;
        public string label;
        public List<string> ranks;
        public List<string> suits;
        public int jokers;
    }

    [Serializable]
    public class BoardDef
    {
        public string id;
        public int cards;
    }

    [Serializable]
    public class SeatsRange
    {
        public int min;
        public int max;
    }

    [Serializable]
    public class VariantDef
    {
        public string id;
        public string label;
        public string deck;
        public string board;
        public string betting;
        public SeatsRange seats;
        public List<string> actions;
        public int holeCards;
        public int communityCards;
        public int timers;
        public string notes;
    }

    [Serializable]
    public class ActionsWrapper
    {
        public List<ActionDef> actions;
    }
    [Serializable]
    public class BettingWrapper
    {
        public List<BettingStyleDef> bettingStyles;
    }
    [Serializable]
    public class DecksWrapper
    {
        public List<DeckDef> decks;
    }
    [Serializable]
    public class BoardsWrapper
    {
        public List<BoardDef> boards;
    }
    [Serializable]
    public class VariantWrapper
    {
        public VariantDef variant;
    }

    /// <summary>
    /// Combines the various definitions into a single ruleset for a game.
    /// This is the Scroll that Zeus produces and the Muses consume.
    /// </summary>
    public class ScrollGameRules
    {
        public DeckDef Deck;
        public BoardDef Board;
        public BettingStyleDef Betting;
        public SeatsRange Seats;
        public List<ActionDef> Actions;
        public int HoleCards;
        public int CommunityCards;
        public int Timers;
        public string Id;
        public string Label;
        public string Notes;
    }
}