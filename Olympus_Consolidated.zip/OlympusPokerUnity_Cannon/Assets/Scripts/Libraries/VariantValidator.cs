using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Olympus.Libraries
{
    public static class VariantValidator
    {
        static readonly HashSet<string> Decks = new(new[] { "Standard52","Standard54Jokers","ShortDeck36" });
        static readonly HashSet<string> Boards = new(new[] { "Community0","Community3","Community4","Community5","DoubleFlop10" });
        static readonly HashSet<string> Betting = new(new[] { "NoLimit","PotLimit","FixedLimit" });
        static readonly HashSet<string> Timers = new(new[] { "Turn","Street","Match" });
        static readonly HashSet<string> PhaseKinds = new(new[] { "Setup","Deal","Passing","Reveal","Betting","Draw","Showdown","Cleanup","Custom" });

        public static List<string> Validate(VariantV2 v)
        {
            var e = new List<string>();
            if (v == null) { e.Add("Variant is null"); return e; }

            // Basics
            if (string.IsNullOrEmpty(v.id)) e.Add("variant.id required");
            if (string.IsNullOrEmpty(v.label)) e.Add("variant.label required");
            if (!Decks.Contains(v.deck)) e.Add($"variant.deck must be one of: {string.Join(",", Decks)}");
            if (!Boards.Contains(v.board)) e.Add($"variant.board must be one of: {string.Join(",", Boards)}");
            if (!Betting.Contains(v.betting)) e.Add($"variant.betting must be one of: {string.Join(",", Betting)}");
            if (v.seats == null || v.seats.min < 2 || v.seats.max < v.seats.min) e.Add("variant.seats invalid");
            if (v.actions == null || v.actions.Count == 0) e.Add("variant.actions required (non-empty)");
            if (v.holeCards < 0) e.Add("variant.holeCards must be >= 0");
            if (v.communityCards < 0) e.Add("variant.communityCards must be >= 0");
            if (v.timers < 0 || v.timers > 3) e.Add("variant.timers must be 0..3");

            // Phases
            if (v.phases == null || v.phases.Count == 0) e.Add("variant.phases required (non-empty)");
            else
            {
                // simple control-flow checks
                var ids = new HashSet<string>();
                int revealed = 0;
                foreach (var p in v.phases)
                {
                    if (p == null) { e.Add("phase null"); continue; }
                    if (string.IsNullOrEmpty(p.id)) e.Add("phase.id required");
                    if (!ids.Add(p.id)) e.Add($"duplicate phase id: {p.id}");
                    if (string.IsNullOrEmpty(p.kind) || !PhaseKinds.Contains(p.kind)) e.Add($"phase.kind invalid for {p.id}");
                    if (p.kind == "Reveal") revealed += Math.Max(0, p.boardReveal);
                    if (p.timers != null && p.timers.Any(t => !Timers.Contains(t))) e.Add($"phase.timers invalid in {p.id}");
                    if (p.kind == "Passing")
                    {
                        if (p.pass == null || string.IsNullOrEmpty(p.pass.direction) || p.pass.count <= 0)
                            e.Add($"phase.pass invalid in {p.id}");
                    }
                    if (p.kind == "Deal")
                    {
                        if (p.deal == null || p.deal.holePerPlayer < 0) e.Add($"phase.deal invalid in {p.id}");
                    }
                }
                if (v.communityCards > 0 && revealed > v.communityCards)
                    e.Add($"phases reveal {revealed} cards but communityCards is {v.communityCards}");
            }

            return e;
        }
    }
}
