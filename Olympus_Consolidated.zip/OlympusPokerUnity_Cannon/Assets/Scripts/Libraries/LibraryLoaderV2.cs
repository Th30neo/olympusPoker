using System;
using System.Collections.Generic;
using UnityEngine;

namespace Olympus.Libraries
{
    public static class LibraryLoaderV2
    {
        public static T LoadJson<T>(string resourcePath)
        {
            var ta = Resources.Load<TextAsset>($"Libraries/{resourcePath}");
            if (ta == null) throw new Exception($"Missing library JSON at Resources/Libraries/{resourcePath}");
            try { return JsonUtility.FromJson<T>(ta.text); }
            catch (Exception ex) { throw new Exception($"JSON parse error in {resourcePath}: {ex.Message}"); }
        }

        public static VariantV2 LoadVariant(string resourcePath)
        {
            var root = LoadJson<VariantV2Root>(resourcePath);
            var v = root.variant;
            var errors = VariantValidator.Validate(v);
            if (errors.Count > 0)
            {
                Debug.LogError($"Variant '{v?.id}' validation errors:\n" + string.Join("\n", errors));
                // Continue returning v so you can choose to run with warnings
            }
            return v;
        }

        // Optional: bridge to ScrollGameRules if your project has it
        public static ScrollGameRules ToScroll(VariantV2 v)
        {
            var scroll = new ScrollGameRules();
            // Map strings to your enums where possible
            scroll.Variant = v.id switch {
                "ShortDeckHoldem" => VariantId.ShortDeckHoldem,
                "Anaconda" => VariantId.Anaconda,
                "Baseball" => VariantId.Baseball,
                _ => VariantId.Holdem
            };

            scroll.Deck = v.deck switch {
                "Standard52" => DeckKind.Standard52,
                "Standard54Jokers" => DeckKind.Standard54Jokers,
                "ShortDeck36" => DeckKind.ShortDeck36,
                _ => DeckKind.Standard52
            };

            scroll.Board = v.board switch {
                "Community0" => BoardLayoutKind.Community0,
                "Community3" => BoardLayoutKind.Community3,
                "Community4" => BoardLayoutKind.Community4,
                "Community5" => BoardLayoutKind.Community5,
                "DoubleFlop10" => BoardLayoutKind.DoubleFlop10,
                _ => BoardLayoutKind.Community5
            };

            scroll.Betting = v.betting switch {
                "PotLimit" => BettingStyle.PotLimit,
                "FixedLimit" => BettingStyle.FixedLimit,
                _ => BettingStyle.NoLimit
            };

            scroll.SeatsMin = v.seats.min;
            scroll.SeatsMax = v.seats.max;
            scroll.AllowedActions = v.actions.ConvertAll(a =>
                Enum.TryParse<ActionType>(ToPascal(a), out var at) ? at : ActionType.Pass
            );
            scroll.JokersWild = v.jokersWild;
            scroll.TimersCount = v.timers;
            return scroll;
        }

        static string ToPascal(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            var parts = s.Split(new[] {'_','-'}, StringSplitOptions.RemoveEmptyEntries);
            for (int i=0;i<parts.Length;i++)
            {
                var p = parts[i];
                parts[i] = char.ToUpperInvariant(p[0]) + (p.Length>1 ? p.Substring(1).ToLowerInvariant() : "");
            }
            return string.Join("", parts);
        }
    }
}
