using System;
using System.Collections.Generic;
using UnityEngine;

namespace Olympus.Libraries
{
    /// <summary>
    /// Loads JSON files from the Resources/Libraries folder and provides
    /// lookup functions for actions, betting styles, decks, boards and variants.
    /// </summary>
    public class LibraryLoader
    {
        private ActionsWrapper _actions;
        private BettingWrapper _betting;
        private DecksWrapper _decks;
        private BoardsWrapper _boards;

        public LibraryLoader()
        {
            LoadLibraries();
        }

        /// <summary>
        /// Loads all core libraries (actions, betting, decks, boards).
        /// </summary>
        private void LoadLibraries()
        {
            _actions = JsonUtility.FromJson<ActionsWrapper>(LoadText("actions"));
            _betting = JsonUtility.FromJson<BettingWrapper>(LoadText("betting"));
            _decks = JsonUtility.FromJson<DecksWrapper>(LoadText("deck"));
            _boards = JsonUtility.FromJson<BoardsWrapper>(LoadText("board"));
        }

        private string LoadText(string name)
        {
            TextAsset asset = Resources.Load<TextAsset>($"Libraries/{name}");
            if (asset == null)
            {
                throw new Exception($"Library {name} could not be loaded from Resources");
            }
            return asset.text;
        }

        public ActionDef GetAction(string id)
        {
            return _actions.actions.Find(a => a.id == id);
        }

        public BettingStyleDef GetBetting(string id)
        {
            return _betting.bettingStyles.Find(b => b.id == id);
        }

        public DeckDef GetDeck(string id)
        {
            return _decks.decks.Find(d => d.id == id);
        }

        public BoardDef GetBoard(string id)
        {
            return _boards.boards.Find(b => b.id == id);
        }

        /// <summary>
        /// Loads a variant from a JSON file in Resources/Libraries.  The file
        /// should have a top‑level object with a single `variant` field.
        /// </summary>
        public VariantDef LoadVariant(string fileName)
        {
            TextAsset asset = Resources.Load<TextAsset>($"Libraries/{fileName}");
            if (asset == null)
            {
                throw new Exception($"Variant file {fileName} could not be loaded");
            }
            var wrapper = JsonUtility.FromJson<VariantWrapper>(asset.text);
            return wrapper.variant;
        }

        /// <summary>
        /// Constructs a ScrollGameRules object by resolving all references
        /// from a variant definition.
        /// </summary>
        public ScrollGameRules BuildRules(VariantDef variant)
        {
            var scroll = new ScrollGameRules
            {
                Id = variant.id,
                Label = variant.label,
                Deck = GetDeck(variant.deck),
                Board = GetBoard(variant.board),
                Betting = GetBetting(variant.betting),
                Seats = variant.seats,
                HoleCards = variant.holeCards,
                CommunityCards = variant.communityCards,
                Timers = variant.timers,
                Notes = variant.notes,
                Actions = new List<ActionDef>()
            };
            foreach (string actId in variant.actions)
            {
                var act = GetAction(actId);
                if (act != null) scroll.Actions.Add(act);
            }
            return scroll;
        }
    }
}