namespace Olympus.Core.Domain
{
    /// <summary>
    /// Categories of five‑card poker hands ranked from lowest to highest.  These
    /// values are used internally by the hand evaluator.
    /// </summary>
    public enum HandRank : int
    {
        HighCard = 0,
        OnePair = 1,
        TwoPair = 2,
        ThreeOfAKind = 3,
        Straight = 4,
        Flush = 5,
        FullHouse = 6,
        FourOfAKind = 7,
        StraightFlush = 8,
        FiveOfAKind = 9
    }
}