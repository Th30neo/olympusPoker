using System;

namespace Olympus.Core.Domain
{
    /// <summary>
    /// Card ranks for a standard deck.  Two is the lowest and Ace is the highest.
    /// For Short Deck (36 cards), the ranks below Six are simply unused.
    /// </summary>
    public enum Rank : int
    {
        Two = 2,
        Three = 3,
        Four = 4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9,
        Ten = 10,
        Jack = 11,
        Queen = 12,
        King = 13,
        Ace = 14
    }
}