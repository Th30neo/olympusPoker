using System;
using System.Collections.Generic;
using Olympus.Core.Domain;

namespace Olympus.Core.Eval
{
    /// <summary>
    /// Extension evaluator methods for non‑standard poker variants.  In
    /// particular, this class provides logic to evaluate Omaha hands by
    /// selecting exactly two hole cards and three board cards.  It also
    /// exposes a comparison helper for ranking hands.
    /// </summary>
    public static class HandEvaluatorExtensions
    {
        /// <summary>
        /// Evaluates the best possible five‑card hand for Omaha given four hole
        /// cards and a five‑card board.  Omaha rules require that the player
        /// use exactly two hole cards and exactly three community cards to
        /// construct their final hand.  This method enumerates all such
        /// combinations and chooses the highest ranked hand using the
        /// existing five‑card evaluator.
        /// </summary>
        /// <param name="hole">Exactly four hole cards.</param>
        /// <param name="board">Exactly five community cards.</param>
        /// <returns>A tuple of hand rank and a list of kicker ranks for tie‑breaking.</returns>
        /// <exception cref="ArgumentException">Thrown if the wrong number of cards are provided.</exception>
        public static (HandRank rank, List<Rank> highCards) EvaluateOmaha(List<Card> hole, List<Card> board)
        {
            if (hole == null || board == null || hole.Count != 4 || board.Count != 5)
            {
                throw new ArgumentException("Omaha evaluation requires 4 hole cards and 5 board cards");
            }
            HandRank bestRank = HandRank.HighCard;
            List<Rank> bestHigh = new List<Rank>();
            // Choose 2 of 4 hole cards
            for (int i = 0; i < 3; i++)
            {
                for (int j = i + 1; j < 4; j++)
                {
                    // Choose 3 of 5 board cards
                    for (int b1 = 0; b1 < 3; b1++)
                    {
                        for (int b2 = b1 + 1; b2 < 4; b2++)
                        {
                            for (int b3 = b2 + 1; b3 < 5; b3++)
                            {
                                var combo = new List<Card>(5)
                                {
                                    hole[i],
                                    hole[j],
                                    board[b1],
                                    board[b2],
                                    board[b3]
                                };
                                var (rank, high) = HandEvaluator.Evaluate5(combo);
                                if (CompareHands(rank, high, bestRank, bestHigh) > 0)
                                {
                                    bestRank = rank;
                                    bestHigh = high;
                                }
                            }
                        }
                    }
                }
            }
            return (bestRank, bestHigh);
        }

        /// <summary>
        /// Compares two hands given their rank categories and kicker lists.  A
        /// higher rank category wins; if the categories are equal then the
        /// kicker lists are compared lexicographically.  Returns 1 if the first
        /// hand is better, -1 if worse, and 0 if they are equal.
        /// </summary>
        public static int CompareHands(HandRank rankA, List<Rank> highA, HandRank rankB, List<Rank> highB)
        {
            if (rankA > rankB) return 1;
            if (rankA < rankB) return -1;
            int n = Math.Min(highA.Count, highB.Count);
            for (int i = 0; i < n; i++)
            {
                if (highA[i] > highB[i]) return 1;
                if (highA[i] < highB[i]) return -1;
            }
            return 0;
        }
    }
}