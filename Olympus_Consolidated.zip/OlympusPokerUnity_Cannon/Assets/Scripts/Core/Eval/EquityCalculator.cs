using System;
using System.Collections.Generic;
using Olympus.Core.Domain;
using Olympus.Core.Deck;

namespace Olympus.Core.Eval
{
    /// <summary>
    /// Performs Monte‑Carlo equity calculations for heads‑up poker games.  The
    /// calculator supports both standard Hold’em as well as other variants
    /// through a generalised method that accepts the number of hole cards
    /// and community cards.  For two hole cards the evaluator uses the
    /// standard seven‑card enumeration; for four hole cards (Omaha) it uses
    /// an Omaha‑specific evaluator that chooses exactly two hole cards and
    /// three board cards.  Other hole counts fall back to seven‑card
    /// evaluation on the first seven cards.
    /// </summary>
    public static class EquityCalculator
    {
        /// <summary>
        /// Computes the equity of hero vs villain given partial board cards for
        /// a standard two‑card Texas Hold’em game.  This method is retained
        /// for backwards compatibility but defers to <see
        /// cref="ComputeEquityGeneral"/> with holeCards=2 and
        /// communityCards=5.
        /// </summary>
        public static (double heroWin, double villainWin, double tie) ComputeEquity(List<Card> hero, List<Card> villain, List<Card> board, List<Card> deck, ApolloRng rng, int iterations = 1000)
        {
            return ComputeEquityGeneral(hero, villain, board, deck, rng, iterations, 2, 5);
        }

        /// <summary>
        /// Computes the equity of hero vs villain given partial board cards for
        /// arbitrary variants.  The number of hole cards and community cards
        /// should match the variant definition.  Unknown community cards are
        /// filled by drawing from the remaining deck.  If the hole card count
        /// is four this method performs Omaha evaluation; otherwise it
        /// performs a seven‑card evaluation using the first seven cards.
        /// </summary>
        /// <param name="hero">Hole cards for the hero.</param>
        /// <param name="villain">Hole cards for the villain.</param>
        /// <param name="board">Known community cards.</param>
        /// <param name="deck">Full deck of cards (including hero/villain/board).</param>
        /// <param name="rng">Deterministic random number generator.</param>
        /// <param name="iterations">Number of Monte‑Carlo simulations.</param>
        /// <param name="holeCards">Number of hole cards for the variant.</param>
        /// <param name="communityCards">Total number of community cards.</param>
        /// <returns>Probabilities of hero win, villain win, and tie.</returns>
        public static (double heroWin, double villainWin, double tie) ComputeEquityGeneral(
            List<Card> hero,
            List<Card> villain,
            List<Card> board,
            List<Card> deck,
            ApolloRng rng,
            int iterations,
            int holeCards,
            int communityCards)
        {
            int heroWins = 0;
            int villainWins = 0;
            int ties = 0;
            // Build a set of used cards to exclude from the pool
            var used = new HashSet<string>();
            foreach (var c in hero) used.Add(c.ToString());
            foreach (var c in villain) used.Add(c.ToString());
            foreach (var c in board) used.Add(c.ToString());
            var available = new List<Card>();
            foreach (var card in deck)
            {
                if (!used.Contains(card.ToString()))
                {
                    available.Add(card);
                }
            }
            for (int iter = 0; iter < iterations; iter++)
            {
                // Shuffle available cards for each simulation
                var pool = new List<Card>(available);
                var poolArray = pool.ToArray();
                rng.Shuffle(poolArray);
                pool = new List<Card>(poolArray);
                // Draw remaining community cards
                int remaining = communityCards - board.Count;
                if (remaining < 0) remaining = 0;
                var drawn = new List<Card>();
                for (int i = 0; i < remaining && i < pool.Count; i++)
                {
                    drawn.Add(pool[i]);
                }
                // Construct full board for this simulation
                var fullBoard = new List<Card>(communityCards);
                fullBoard.AddRange(board);
                fullBoard.AddRange(drawn);
                // Evaluate hero and villain hands.
                HandRank heroRank;
                List<Rank> heroHigh;
                HandRank villainRank;
                List<Rank> villainHigh;
                if (holeCards == 4 && fullBoard.Count == 5)
                {
                    // Omaha: choose exactly 2 of 4 hole cards and 3 of 5 board cards.
                    var heroRes = HandEvaluatorExtensions.EvaluateOmaha(hero, fullBoard);
                    var villainRes = HandEvaluatorExtensions.EvaluateOmaha(villain, fullBoard);
                    heroRank = heroRes.rank;
                    heroHigh = heroRes.highCards;
                    villainRank = villainRes.rank;
                    villainHigh = villainRes.highCards;
                }
                else
                {
                    // Standard: build a 7‑card hand from hole and board.  If the
                    // combined count exceeds 7 we take the first seven cards; if
                    // it is less than 7 we pad with cards from the pool.
                    var heroCards = new List<Card>();
                    heroCards.AddRange(hero);
                    heroCards.AddRange(fullBoard);
                    var villainCards = new List<Card>();
                    villainCards.AddRange(villain);
                    villainCards.AddRange(fullBoard);
                    int padIndexH = remaining;
                    while (heroCards.Count < 7 && padIndexH < pool.Count)
                    {
                        heroCards.Add(pool[padIndexH++]);
                    }
                    int padIndexV = remaining;
                    while (villainCards.Count < 7 && padIndexV < pool.Count)
                    {
                        villainCards.Add(pool[padIndexV++]);
                    }
                    if (heroCards.Count > 7) heroCards = heroCards.GetRange(0, 7);
                    if (villainCards.Count > 7) villainCards = villainCards.GetRange(0, 7);
                    var heroEvalTuple = HandEvaluator.Evaluate7(heroCards);
                    heroRank = heroEvalTuple.rank;
                    heroHigh = heroEvalTuple.highCards;
                    var villainEvalTuple = HandEvaluator.Evaluate7(villainCards);
                    villainRank = villainEvalTuple.rank;
                    villainHigh = villainEvalTuple.highCards;
                }
                // Compare results using helper from HandEvaluatorExtensions
                int cmp = HandEvaluatorExtensions.CompareHands(heroRank, heroHigh, villainRank, villainHigh);
                if (cmp > 0) heroWins++;
                else if (cmp < 0) villainWins++;
                else ties++;
            }
            double total = heroWins + villainWins + ties;
            return total > 0 ? (heroWins / total, villainWins / total, ties / total) : (0, 0, 1);
        }
    }
}