using UnityEngine;
using Olympus.Libraries;

namespace Olympus.Gods
{
    /// <summary>
    /// Athena validates scrolls forged by Zeus.  She ensures that
    /// seat counts, board sizes and other parameters are within
    /// reasonable bounds.  In this simple implementation she logs
    /// warnings but always returns true.
    /// </summary>
    public class Athena
    {
        public bool Validate(ScrollGameRules scroll)
        {
            bool valid = true;
            if (scroll.Seats.min < 2 || scroll.Seats.max < scroll.Seats.min)
            {
                Debug.LogWarning($"Invalid seat range: {scroll.Seats.min}-{scroll.Seats.max}");
                valid = false;
            }
            if (scroll.HoleCards < 1 || scroll.HoleCards > 4)
            {
                Debug.LogWarning($"Suspicious hole card count: {scroll.HoleCards}");
            }
            if (scroll.CommunityCards < 0 || scroll.CommunityCards > 10)
            {
                Debug.LogWarning($"Board card count out of bounds: {scroll.CommunityCards}");
            }
            return valid;
        }
    }
}