using System;
using Olympus.Libraries;
using Olympus.Platform;

namespace Olympus.Gods
{
    /// <summary>
    /// Hermes acts as the messenger between the game and external platforms.
    /// Muses publish events to Hermes, and Hermes forwards them to the
    /// configured platform adapter (if any).  External platforms can also
    /// trigger events via Hermes.
    /// </summary>
    public static class Hermes
    {
        private static IPlatformAdapter _adapter;

        /// <summary>
        /// Registers a platform adapter.  Only one adapter may be registered at
        /// a time.
        /// </summary>
        public static void RegisterAdapter(IPlatformAdapter adapter)
        {
            _adapter = adapter;
        }

        public static void UnregisterAdapter()
        {
            _adapter = null;
        }

        /// <summary>
        /// Called when the match is ready to start.  Forwards the event to the
        /// platform adapter.
        /// </summary>
        public static void MatchReady(string modeId)
        {
            _adapter?.OnMatchReady(modeId);
        }

        /// <summary>
        /// Called when the match result is available.  Forwards the result to
        /// the platform adapter.
        /// </summary>
        public static void SubmitResult(int score)
        {
            _adapter?.SubmitResult(score);
        }

        /// <summary>
        /// Called when a fatal error occurs.  Forwards the error to the platform
        /// adapter.
        /// </summary>
        public static void Error(string message)
        {
            _adapter?.OnError(message);
        }
    }
}