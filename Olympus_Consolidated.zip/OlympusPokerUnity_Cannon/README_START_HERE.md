# Olympus Poker Unity — Full Edition

This project demonstrates a **modular poker framework** built in Unity.  The code is
structured around a mythological metaphor: **Gods** assemble rule sets (called
scrolls) from libraries, **Muses** run the game loop, **Demigods** mediate
between the UI and the engine, and **Hermes** acts as the message bus.  The
optional server integration uses the open‑source **PokerKit** library to
evaluate hands and compute equity.

## Getting Started

1. **Install Unity 2022.3 LTS or newer.**  Earlier versions may work but
   2022.3+ is recommended.
2. **Unzip this project** and open the `OlympusPokerUnity_Cannon` folder as a
   Unity project.  This edition builds upon the previous Full version and
   integrates the official PokerKit Python library from the
   [uoftcprg/pokerkit](https://github.com/uoftcprg/pokerkit) repository.  The
   optional FastAPI service included in `ServerIntegration` calls into
   PokerKit to evaluate hands; it will load PokerKit from your Python
   environment (see below).
3. **Create a new scene**, add an empty GameObject, and attach the
   `Olympus.Bootstrap.OlympusBootstrap` component to it.
4. **Press Play.**  The default Hold’em variant will load a seeded deck,
   distribute cards, and print the equity of two random hands to the console.

## Libraries and Scrolls

Rule definitions live in the `Assets/Resources/Libraries` folder as JSON
files.  Each file defines a particular aspect of poker (actions, betting
styles, decks, board layouts, and full variants).  The Gods read these
libraries and construct a **Scroll** describing a specific game.  The
default variant (`variant_holdem.json`) demonstrates how to specify:

- **Deck type:** standard 52 cards, short‑deck (36), or jokers.
- **Board layout:** community board with 0–10 cards.
- **Betting style:** NoLimit, PotLimit, or FixedLimit.
- **Seating:** number of players (2–10).
- **Actions:** check, bet, call, fold, all‑in, raise×2/×3/×4, discard, pass.
- **Timers:** up to three concurrent timers per game (e.g. turn timer,
  street timer, match timer).

You can add new variants (e.g. Omaha, Short Deck, Stud, Baseball, Anaconda)
by creating additional `variant_*.json` files and expanding the enums in
`Scripts/Libraries/Schemas.cs`.  The Muses will read whatever scroll
Zeus produces and run the corresponding game logic.  PokerKit itself
allows users to define or adapt almost any poker variant without
compromising robustness【436577811069923†L77-L87】; common variants such as
Fixed‑Limit Badugi, Deuce‑to‑Seven Lowball, Short‑Deck Hold’em and
Pot‑Limit Omaha are provided out of the box【436577811069923†L110-L164】.

## PokerKit Microservice

The `ServerIntegration` folder contains a FastAPI service (`pokerkit_service.py`)
that exposes endpoints for hand evaluation and equity calculation using
the [PokerKit](https://pokerkit.readthedocs.io/) library.  This service
allows Unity to call PokerKit over HTTP rather than embedding Python.  To
run the service locally:

```bash
cd ServerIntegration
python -m venv .venv
# Activate the virtual environment
source .venv/bin/activate    # on Windows use .\.venv\Scripts\activate
pip install pokerkit fastapi uvicorn
uvicorn pokerkit_service:app --host 0.0.0.0 --port 8089
```

When the service is running on port 8089, Unity’s `PokerKitClient` will
automatically detect it on `http://localhost:8089` and request equities via
`/api/v1/holdem/equity`.  You can customise the base URL in `PokerKitClient.cs`.

### Why PokerKit?

PokerKit is a mature, permissively licensed engine for simulating a wide
range of poker games.  Its features include **extensive game logic for major
and minor poker variants, high‑speed hand evaluations, customizable game
states and parameters, and a robust implementation backed by static type
checking and extensive tests【371441807000289†L285-L292】**.  PokerKit is
distributed under the MIT license【371441807000289†L786-L788】, requires
Python 3.11 or newer to install【371441807000289†L293-L296】 and, at the time
of writing, the latest release is version 0.6.3 (March 28 2025)【371441807000289†L861-L862】.

This project includes a lightweight wrapper around PokerKit so you can
evaluate hands and compute equities from Unity without embedding Python.
However, you can also rely solely on the included C# evaluators and
equity calculator for offline or deterministic play.  For Omaha variants
this project implements a native evaluator that chooses exactly two of
four hole cards and three community cards, allowing Monte‑Carlo equity
calculations without contacting the server.

## Structure

- `Assets/Scripts/Core` – fundamental types (cards, suits, ranks), deck
  construction, random number generator, hand evaluators, equity calculator.
- `Assets/Scripts/Gods` – Zeus/Athena/Apollo/Hermes classes.  Zeus forges
  scrolls, Athena validates them, Apollo provides deterministic RNG and deck
  shuffling, and Hermes serves as an event bus and platform bridge.
- `Assets/Scripts/Muses` – gameplay loop, dealing, board setup based on the
  scroll, rule enforcement, and delegation of actions to mortals.
- `Assets/Scripts/Demigods` – UI bridge between players and the game core,
  logging and reporting results back to the gods.
- `Assets/Scripts/Libraries` – schemas for JSON libraries and a loader.
- `Assets/Scripts/Platform` – base interfaces for platform adapters and a
  PokerKit client that uses UnityWebRequest to call the microservice.
- `Assets/Scripts/Services` – timer service supporting up to three independent
  timers per game.
- `Assets/Scripts/Bootstrap` – entry point (`OlympusBootstrap`) that ties
  everything together for the demo.
- `Assets/Resources/Libraries` – JSON files defining decks, boards, betting
  styles, actions, and complete variants.
- `ServerIntegration` – FastAPI microservice that wraps PokerKit.
- `ProjectSettings` and `Packages` – minimal Unity metadata to open the
  project.

## Extending the Project

- **New variants:** Add `variant_*.json` files with custom settings
  (board size, deck type, betting, actions) and implement any special rules in
  `MuseOfGameplay.cs`.
- **Betting engine:** The current implementation logs permitted actions but
  does not enforce pot/limit sizes.  Extend the `BettingStyle` enum and add
  logic in the Muse to enforce raise caps and blind structures.
- **Timers:** You can schedule up to three timers per game using
  `TimerService`.  Use these for turn clocks, street clocks, or match
  duration.  The service will invoke callbacks when timers expire.
- **Skillz integration:** Implement `SkillzPlatformAdapter : IPlatformAdapter` and
  plug it into Hermes.  Map the Skillz SDK callbacks (match start, match
  completed) to the methods defined in `IPlatformAdapter`.

## Notes

This project is intended as an educational sample and starting point.  It
demonstrates how to build a modular card‑game engine in Unity and how to
incorporate external libraries such as PokerKit.  The design emphasises
clear separation of concerns, deterministic RNG for fairness, and data‑driven
rule definition via JSON.
