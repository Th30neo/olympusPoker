using System.Collections;
using UnityEngine;
using Olympus.Systems;
using Olympus.UI;

namespace Olympus.Controllers
{
    public class HandController : MonoBehaviour
    {
        public float phaseDelay = 2f;

        public void StartHand()
        {
            StartCoroutine(RunHand());
        }

        private IEnumerator RunHand()
        {
            while (true)
            {
                PhaseData phase = null;
                yield return StartCoroutine(PokerBridge.FetchNextPhase((p) => phase = p));

                if (phase == null || phase.phase == "done")
                    break;

                Debug.Log($"Phase: {phase.phase}");

                if (phase.hero != null && phase.villain != null && phase.board != null)
                {
                    CardSpawner.ShowCards(phase.hero, phase.villain, phase.board);
                }

                if (phase.equities != null)
                {
                    EquityDisplay.UpdateEquities(phase.equities);
                }

                yield return new WaitForSeconds(phaseDelay);
            }
        }
    }
}
