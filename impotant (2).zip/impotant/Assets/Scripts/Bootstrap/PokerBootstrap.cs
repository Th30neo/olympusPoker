using UnityEngine;
using Olympus.Controllers;

namespace Olympus.Bootstrap
{
    public class PokerBootstrap : MonoBehaviour
    {
        private void Start()
        {
            var controller = gameObject.AddComponent<HandController>();
            controller.StartHand();
        }
    }
}
