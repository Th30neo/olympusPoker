using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;

namespace Olympus.Systems
{
    [System.Serializable]
    public class PhaseData
    {
        public string phase;
        public List<string> hero;
        public List<string> villain;
        public List<string> board;
        public EquityData equities;
        public string winner;
    }

    [Serializable]
    public class EquityData
    {
        public float hero;
        public float villain;
    }

    public class PokerBridge
    {
        public static IEnumerator FetchNextPhase(Action<PhaseData> callback)
        {
            string url = "http://127.0.0.1:8000/next_phase";
            UnityWebRequest request = UnityWebRequest.Get(url);
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                var json = request.downloadHandler.text;

                // Unity's JsonUtility requires wrapper objects if you want lists,
                // but here we�re good because Python returns arrays for hero/villain/board
                PhaseData phase = JsonUtility.FromJson<PhaseData>(json);

                callback?.Invoke(phase);
            }
            else
            {
                Debug.LogError("PokerBridge failed: " + request.error);
                callback?.Invoke(null);
            }
        }
    }
}
