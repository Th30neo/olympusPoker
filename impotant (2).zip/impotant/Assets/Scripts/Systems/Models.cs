using System;

namespace Olympus.Systems
{
    public enum Suit { Clubs, Diamonds, Hearts, Spades }
    public enum Rank { Two=2, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace }

    public struct Card
    {
        public Rank Rank;
        public Suit Suit;

        public Card(Rank rank, Suit suit)
        {
            Rank = rank;
            Suit = suit;
        }

        public override string ToString() => $"{Rank} of {Suit}";

        public static Card FromString(string s)
        {
            // Example: "As" = Ace Spades, "kd" = King Diamonds
            s = s.Trim().ToLower();
            char rankChar = s[0];
            char suitChar = s[1];

            Rank rank = Rank.Two;
            switch (rankChar)
            {
                case '2': rank = Rank.Two; break;
                case '3': rank = Rank.Three; break;
                case '4': rank = Rank.Four; break;
                case '5': rank = Rank.Five; break;
                case '6': rank = Rank.Six; break;
                case '7': rank = Rank.Seven; break;
                case '8': rank = Rank.Eight; break;
                case '9': rank = Rank.Nine; break;
                case 't': rank = Rank.Ten; break;
                case 'j': rank = Rank.Jack; break;
                case 'q': rank = Rank.Queen; break;
                case 'k': rank = Rank.King; break;
                case 'a': rank = Rank.Ace; break;
            }

            Suit suit = Suit.Spades;
            switch (suitChar)
            {
                case 'c': suit = Suit.Clubs; break;
                case 'd': suit = Suit.Diamonds; break;
                case 'h': suit = Suit.Hearts; break;
                case 's': suit = Suit.Spades; break;
            }

            return new Card(rank, suit);
        }

        public static string Key(string s) => s.ToLower(); // used for CardAtlas sprite lookup
    }
}
