using UnityEngine;
using UnityEngine.UI;
using Olympus.Systems;

namespace Olympus.UI
{
    public class EquityDisplay : MonoBehaviour
    {
        private static Text equityText;

        private void Awake()
        {
            equityText = GetComponent<Text>();
        }

        public static void UpdateEquities(EquityData equities)
        {
            if (equityText == null || equities == null) return;

            equityText.text =
                $"Hero: {equities.hero * 100:F1}%\n" +
                $"Villain: {equities.villain * 100:F1}%";
        }
    }
}
