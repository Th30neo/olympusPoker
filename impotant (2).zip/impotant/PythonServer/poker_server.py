from fastapi import FastAPI
from fastapi.responses import JSONResponse
import uvicorn
from pokerkit import NoLimitTexasHoldem, Automation, Mode
import random

app = FastAPI()

# Global state
state = None
phases = []
phase_index = 0

@app.on_event("startup")
def setup_game():
    """Initialize the PokerKit game state once when the server starts"""
    global state, phases, phase_index

    random.seed()

    state = NoLimitTexasHoldem.create_state(
        (Automation.ANTE_POSTING,),  # automation flags supported in your PokerKit version
        False,
        {-1: 100}, (5, 10), 10, (1000, 1000), 2,
        mode=Mode.CASH_GAME
    )

    # Reset trackers
    phases.clear()
    phase_index = 0

    hero, villain, board = [], [], []

    # Step through state and record "phases"
    while not state.is_terminal:
        state.proceed()

        # Hole cards
        if state.hole_cards:
            hero = [str(c).lower() for c in state.hole_cards[0]]
            villain = [str(c).lower() for c in state.hole_cards[1]]
            phases.append({
                "phase": "hole",
                "hero": hero,
                "villain": villain,
                "board": [],
                "equities": {"hero": 0.5, "villain": 0.5}  # placeholder equity
            })

        # Community board
        if state.board:
            board = [str(c).lower() for c in state.board]
            phases.append({
                "phase": f"board_{len(board)}",
                "hero": hero,
                "villain": villain,
                "board": board,
                "equities": {"hero": 0.5, "villain": 0.5}  # placeholder equity
            })

    # Showdown
    if state.is_terminal:
        phases.append({
            "phase": "showdown",
            "winner": "tbd"  # real hand eval can be added later
        })


@app.get("/")
def root():
    """Friendly root route so hitting / doesn't 404"""
    return {"status": "PokerKit server is running. Use /next_phase to step through a hand."}


@app.get("/next_phase")
def next_phase():
    """Return the next phase of the current hand"""
    global phase_index

    if phase_index < len(phases):
        phase = phases[phase_index]
        phase_index += 1
        return JSONResponse(content=phase)
    else:
        return JSONResponse(content={"phase": "done"})


@app.get("/new_hand")
def new_hand():
    """Reset and deal a new hand"""
    setup_game()
    return {"status": "new hand started"}


if __name__ == "__main__":
    uvicorn.run("poker_server:app", host="127.0.0.1", port=8000, reload=True)
