using UnityEngine;
using System.Collections.Generic;

namespace Olympus.UI
{
    [CreateAssetMenu(fileName = "CardAtlas", menuName = "Olympus/Card Atlas")]
    public class CardAtlas : ScriptableObject
    {
        private static CardAtlas _instance;
        public static CardAtlas Instance
        {
            get
            {
                if (_instance == null)
                    _instance = Resources.Load<CardAtlas>("CardAtlas");
                return _instance;
            }
        }

        [Header("Card Sprites")]
        public List<Sprite> cardSprites = new List<Sprite>();

        private Dictionary<string, Sprite> lookup;

        private void OnEnable() => BuildLookup();

        private void BuildLookup()
        {
            lookup = new Dictionary<string, Sprite>();
            foreach (var sprite in cardSprites)
            {
                if (sprite == null) continue;
                lookup[sprite.name.ToLower()] = sprite;
            }
        }

        public Sprite GetSprite(string cardCode)
        {
            if (lookup == null) BuildLookup();
            string key = cardCode.ToLower(); // "as", "kd", etc.
            if (lookup.TryGetValue(key, out var sprite))
                return sprite;

            Debug.LogWarning($"CardAtlas missing sprite for {key}");
            return null;
        }
    }
}
