using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;

namespace Olympus.Systems
{
    [System.Serializable]
    public class PhaseData
    {
        public string phase;
        public List<string> hero;
        public List<string> villain;
        public List<string> board;
        public Dictionary<string, float> equities;
        public string winner;
    }

    public class PokerBridge
    {
        public static IEnumerator FetchNextPhase(Action<PhaseData> callback)
        {
            string url = "http://127.0.0.1:8000/next_phase";
            UnityWebRequest request = UnityWebRequest.Get(url);
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                var json = request.downloadHandler.text;
                var phase = JsonConvert.DeserializeObject<PhaseData>(json);
                callback?.Invoke(phase);
            }
            else
            {
                Debug.LogError("PokerBridge failed: " + request.error);
                callback?.Invoke(null);
            }
        }
    }
}
