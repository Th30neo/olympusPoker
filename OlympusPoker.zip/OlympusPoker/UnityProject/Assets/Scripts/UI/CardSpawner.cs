using UnityEngine;
using System.Collections.Generic;

namespace Olympus.UI
{
    public class CardSpawner : MonoBehaviour
    {
        [Header("Card Prefab")]
        public GameObject cardPrefab;

        [Header("Anchors")]
        public Transform cardAnchor;

        [Header("Layout")]
        public float spacing = 1.5f;
        public Vector3 heroPosition = new Vector3(-3f, -2f, 1f);
        public Vector3 villainPosition = new Vector3(-3f,  2f, 1f);
        public Vector3 boardPosition = new Vector3(-5f,   0f, 1f);

        private static CardSpawner _instance;

        private void Awake()
        {
            _instance = this;
        }

        public static void ShowCards(List<string> hero, List<string> villain, List<string> board)
        {
            if (_instance == null) return;
            _instance.SpawnCards(hero, villain, board);
        }

        private void SpawnCards(List<string> hero, List<string> villain, List<string> board)
        {
            // Clear old cards
            foreach (Transform child in cardAnchor)
                Destroy(child.gameObject);

            // Hero hole cards
            for (int i = 0; i < hero.Count; i++)
                SpawnCard(hero[i], heroPosition + Vector3.right * i * spacing, "Hero");

            // Villain hole cards
            for (int i = 0; i < villain.Count; i++)
                SpawnCard(villain[i], villainPosition + Vector3.right * i * spacing, "Villain");

            // Board
            for (int i = 0; i < board.Count; i++)
                SpawnCard(board[i], boardPosition + Vector3.right * i * spacing, "Board");
        }

        private void SpawnCard(string cardCode, Vector3 position, string owner)
        {
            var go = Instantiate(cardPrefab, position, Quaternion.identity, cardAnchor);
            go.name = $"{owner}_{cardCode}";

            var sr = go.GetComponent<SpriteRenderer>();
            if (sr != null)
            {
                sr.sortingLayerName = "Cards";
                sr.sortingOrder = 5;
                sr.color = Color.white;

                // Lookup in CardAtlas
                Sprite sprite = CardAtlas.Instance.GetSprite(cardCode);
                if (sprite != null) sr.sprite = sprite;
                else Debug.LogWarning($"Missing sprite for {cardCode}");
            }
        }
    }
}
