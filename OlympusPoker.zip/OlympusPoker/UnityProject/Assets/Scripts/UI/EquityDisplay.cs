using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Olympus.UI
{
    public class EquityDisplay : MonoBehaviour
    {
        private static Text equityText;

        private void Awake()
        {
            equityText = GetComponent<Text>();
        }

        public static void UpdateEquities(Dictionary<string, float> equities)
        {
            if (equityText == null) return;

            if (equities.ContainsKey("hero") && equities.ContainsKey("villain"))
            {
                equityText.text =
                    $"Hero: {equities["hero"] * 100:F1}%\n" +
                    $"Villain: {equities["villain"] * 100:F1}%";
            }
        }
    }
}
