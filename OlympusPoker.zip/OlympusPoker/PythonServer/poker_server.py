from fastapi import FastAPI
from fastapi.responses import JSONResponse
import uvicorn
from pokerkit import NoLimitTexasHoldem, Automation, Mode
import random

app = FastAPI()

# globals
state = None
phases = []
phase_index = 0

@app.on_event("startup")
def setup_game():
    global state, phases, phase_index

    random.seed()

    state = NoLimitTexasHoldem.create_state(
        (Automation.ANTE_POSTING,),  # only automation flag supported in your version
        False, {-1: 100},
        (5, 10), 10, (1000, 1000), 2,
        mode=Mode.CASH_GAME
    )

    # TODO: Real stepping through state with state.proceed() would go here
    # For now, let's hardcode a demo hand to prove pipeline works.
    hero = ["As", "Kd"]
    villain = ["9d", "9s"]
    board = []

    phases = []
    phases.append({
        "phase": "hole",
        "hero": hero, "villain": villain,
        "board": [], "equities": {"hero": 0.50, "villain": 0.50}
    })

    board = ["7d", "Qh", "8c"]
    phases.append({
        "phase": "flop",
        "hero": hero, "villain": villain,
        "board": board, "equities": {"hero": 0.42, "villain": 0.58}
    })

    board.append("4s")
    phases.append({
        "phase": "turn",
        "hero": hero, "villain": villain,
        "board": board.copy(), "equities": {"hero": 0.35, "villain": 0.65}
    })

    board.append("8h")
    phases.append({
        "phase": "river",
        "hero": hero, "villain": villain,
        "board": board.copy(), "equities": {"hero": 0.0, "villain": 1.0}
    })

    phases.append({"phase": "showdown", "winner": "villain"})
    phase_index = 0

@app.get("/next_phase")
def next_phase():
    global phase_index
    if phase_index < len(phases):
        phase = phases[phase_index]
        phase_index += 1
        return JSONResponse(content=phase)
    return JSONResponse(content={"phase": "done"})

if __name__ == "__main__":
    uvicorn.run("poker_server:app", host="127.0.0.1", port=8000, reload=True)
