# PokerKit Microservice

This folder contains a lightweight **FastAPI** service that wraps the
[PokerKit](https://pokerkit.readthedocs.io/) library.  Running this service
locally (or on a remote host) allows the Unity client to evaluate poker
hands and compute equities without embedding Python into the game client.

## Running the Service

1. Navigate into this folder:

   ```bash
   cd ServerIntegration
   ```

2. Create and activate a Python virtual environment:

   ```bash
   python -m venv .venv
   # On Unix
   source .venv/bin/activate
   # On Windows
   # .\.venv\Scripts\activate
   ```

3. Install dependencies (PokerKit, FastAPI, Uvicorn) from the provided
   `requirements.txt` file.  Ensure that you have Python 3.11 or newer
   installed, as PokerKit requires Python 3.11【371441807000289†L293-L296】.

   ```bash
   pip install -r requirements.txt
   ```

4. Start the server on port 8089:

   ```bash
   uvicorn pokerkit_service:app --host 0.0.0.0 --port 8089
   ```

This service uses the open‑source PokerKit library to evaluate hands.  If
the library is not already installed, pip will fetch it from PyPI.  When
the service is running on port 8089, the Unity client
(`PokerKitClient.cs`) can request equity calculations via
`http://localhost:8089/api/v1/holdem/equity`.

> **Note**: The included `olympus_poker_os` folder contains utility
functions such as Calliope’s narration, ported from a previous C++
implementation.  You can import these functions into the service to
generate human‑readable descriptions of evaluation results, or extend the
service with additional endpoints.

## API Endpoint

`POST /api/v1/holdem/equity`

Request body:

```json
{
  "hero": ["As", "Kh"],      // two hole cards for the hero
  "villain": ["Qc", "Jd"],  // two hole cards for the villain
  "board": ["2c", "7d", "Tc"]  // optional community cards (0–5 cards)
}
```

Response:

```json
{
  "hero_win": 1.0,
  "villain_win": 0.0,
  "tie": 0.0
}
```

The endpoint detects invalid or duplicate cards and returns an HTTP 400
response with a descriptive error message.  This simple implementation
compares the hero and villain hands deterministically; it does not run
Monte‑Carlo simulations.  You can extend it to support simulations,
multiple villains, multi‑runout scenarios, or other variants.
