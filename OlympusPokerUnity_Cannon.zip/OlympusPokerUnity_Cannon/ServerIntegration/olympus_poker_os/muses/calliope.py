"""
Utilities for narrating poker hand outcomes.

This module provides a single function, :func:`narrate`, which turns
structured evaluation results into a human‑readable string.  Previously
multiple conflicting definitions of the function existed; they have been
consolidated here and improved to be more robust.
"""

from typing import Any, Dict, Iterable


def narrate(event: Dict[str, Any]) -> str:
    """Generate a narration for a poker event.

    If the event dictionary contains a ``"results"`` key with an iterable of
    per‑player results, each result will be formatted on its own line as
    ``"Player <id> → <description>"``.  When a description is absent the
    entire result object is stringified.  If ``"results"`` is not present
    the entire event dictionary will be interpolated into the output.

    Parameters
    ----------
    event : dict
        The event payload to narrate.  This is typically the parsed JSON
        returned by Hermes after judging hands.

    Returns
    -------
    str
        A human‑readable narration of the event.
    """
    if isinstance(event, dict) and "results" in event:
        results = event.get("results")
        if isinstance(results, Iterable):
            lines = []
            for r in results:
                # Each result is expected to be a mapping with at least a
                # playerId.  Use a fallback "?" when missing.
                player_id = r.get("playerId", "?") if isinstance(r, dict) else "?"
                description = None
                if isinstance(r, dict):
                    # Prefer explicit description key; fall back to str(r)
                    description = r.get("description")
                if description is None:
                    description = str(r)
                lines.append(f"Player {player_id} → {description}")
            return "Calliope sings:\n" + "\n".join(lines)
    # Fallback: return the simple string representation of the event
    return f"Calliope sings: {event}"