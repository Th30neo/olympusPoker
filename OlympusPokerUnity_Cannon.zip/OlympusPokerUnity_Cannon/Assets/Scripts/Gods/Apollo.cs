using Olympus.Core.Deck;

namespace Olympus.Gods
{
    /// <summary>
    /// Apollo provides deterministic random number generation for the game.
    /// Use this class to create a seeded <see cref="ApolloRng"/>.
    /// </summary>
    public class Apollo
    {
        private readonly int _seed;

        public Apollo(int seed)
        {
            _seed = seed;
        }

        public ApolloRng CreateRng()
        {
            return new ApolloRng(_seed);
        }
    }
}