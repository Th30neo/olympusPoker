using Olympus.Libraries;
using UnityEngine;

namespace Olympus.Gods
{
    /// <summary>
    /// Zeus is responsible for forging scrolls from the libraries.  He
    /// selects a variant, resolves its dependencies, and produces a
    /// ScrollGameRules object.  In a more advanced implementation, Zeus
    /// could randomly assemble rules from multiple libraries.
    /// </summary>
    public class Zeus
    {
        private readonly LibraryLoader _loader;

        public Zeus(LibraryLoader loader)
        {
            _loader = loader;
        }

        /// <summary>
        /// Loads a variant file from the Resources/Libraries folder and
        /// constructs a ScrollGameRules instance.
        /// </summary>
        public ScrollGameRules ForgeScroll(string variantFileName)
        {
            VariantDef def = _loader.LoadVariant(variantFileName);
            return _loader.BuildRules(def);
        }
    }
}