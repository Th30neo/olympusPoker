// Assets/Scripts/Libraries/Schemas.cs
using System.Collections.Generic;
using UnityEngine;

namespace Olympus.Libraries
{
    /// <summary>
    /// Canonical list of allowed actions. Extend as needed, but keep these names.
    /// </summary>
    public enum ActionType
    {
        None = 0,
        Check,
        Call,
        Bet,
        Raise,
        Fold,
        AllIn,
        BringIn,
        Straddle,
        Discard,     // draw variants
        StandPat     // draw variants
    }

    /// <summary>Deck families referenced by rules & loaders.</summary>
    public enum DeckKind
    {
        Standard52 = 0,
        ShortDeck36,
        Standard52_Jokers2,
        Custom
    }

    /// <summary>Community/board layout families.</summary>
    public enum BoardLayoutKind
    {
        None = 0,           // Stud / Draw
        FlopTurnRiver,      // Hold’em
        FiveStreetReveal,   // Stud style
        DoubleFlop,         // Double-flop Hold’em
        Custom
    }

    /// <summary>Betting styles supported by rules.</summary>
    public enum BettingStyle
    {
        FixedLimit = 0,
        NoLimit,
        PotLimit,
        SpreadLimit,
        CapLimit
    }

    /// <summary>
    /// Single, unified Scroll used by Zeus/Athena/Muse. 
    /// This adds the properties LibraryLoaderV2 references.
    /// </summary>
    [System.Serializable]
    public class ScrollGameRules
    {
        // Identity
        public string Id;                 // e.g., "NoLimitHoldem"
        public string Variant;            // human-ish variant name (e.g., "holdem", "doubleflop_holdem")

        // Seats
        public int SeatsMin = 2;
        public int SeatsMax = 2;

        // Deck / Board / Betting skeleton
        public DeckKind Deck = DeckKind.Standard52;
        public BoardLayoutKind BoardLayout = BoardLayoutKind.FlopTurnRiver;
        public BettingStyle Betting = BettingStyle.NoLimit;

        // Actions & toggles
        public List<ActionType> AllowedActions = new List<ActionType> { ActionType.Check, ActionType.Call, ActionType.Bet, ActionType.Raise, ActionType.Fold, ActionType.AllIn };
        public bool JokersWild = false;

        // Simple timer count (V2 can define a richer timer table; this keeps the old code happy)
        public int TimersCount = 0;

        // Optional: anything else you already had can remain
        // public object Custom; ...
    }

    // ------------------- V2 DTOs (kept separate so JSON -> Scroll is explicit) -------------------

    [System.Serializable]
    public class VariantV2Root
    {
        public VariantV2 variant;
    }

    /// <summary>
    /// Minimal V2 schema we need to map into ScrollGameRules. Extend freely.
    /// </summary>
    [System.Serializable]
    public class VariantV2
    {
        public string id;                 // "doubleflop_holdem_v2"
        public string name;               // display
        public string family;             // "holdem", "stud", ...
        public V2Seats seats;
        public V2Deck deck;
        public V2Board board;
        public V2Betting betting;
        public V2Actions actions;
        public V2Timers timers;
        public V2Toggles toggles;
    }

    [System.Serializable] public class V2Seats { public int min; public int max; }
    [System.Serializable] public class V2Deck { public string kind; public bool jokers; }
    [System.Serializable] public class V2Board { public string layout; } // e.g., "flopTurnRiver", "doubleFlop"
    [System.Serializable] public class V2Betting { public string style; } // "noLimit", "fixedLimit", "potLimit"
    [System.Serializable] public class V2Actions { public List<string> allow; }
    [System.Serializable] public class V2Timers { public int count; }
    [System.Serializable] public class V2Toggles { public bool jokersWild; }

    /// <summary>Utility helpers for mapping text tokens to enums.</summary>
    public static class SchemaMaps
    {
        public static DeckKind ParseDeckKind(string s)
        {
            if (string.IsNullOrEmpty(s)) return DeckKind.Standard52;
            switch (s.ToLowerInvariant())
            {
                case "standard52": return DeckKind.Standard52;
                case "shortdeck": return DeckKind.ShortDeck36;
                case "standard52_jokers2": return DeckKind.Standard52_Jokers2;
                default: return DeckKind.Custom;
            }
        }

        public static BoardLayoutKind ParseBoardLayout(string s)
        {
            if (string.IsNullOrEmpty(s)) return BoardLayoutKind.FlopTurnRiver;
            switch (s.ToLowerInvariant())
            {
                case "none": return BoardLayoutKind.None;
                case "flopturnriver": return BoardLayoutKind.FlopTurnRiver;
                case "doublestreet"  : return BoardLayoutKind.FiveStreetReveal; // alias if your json uses it
                case "doubleflop"    : return BoardLayoutKind.DoubleFlop;
                default: return BoardLayoutKind.Custom;
            }
        }

        public static BettingStyle ParseBettingStyle(string s)
        {
            if (string.IsNullOrEmpty(s)) return BettingStyle.NoLimit;
            switch (s.ToLowerInvariant())
            {
                case "fixedlimit": return BettingStyle.FixedLimit;
                case "nolimit":    return BettingStyle.NoLimit;
                case "potlimit":   return BettingStyle.PotLimit;
                case "spreadlimit":return BettingStyle.SpreadLimit;
                case "caplimit":   return BettingStyle.CapLimit;
                default:           return BettingStyle.NoLimit;
            }
        }

        public static ActionType ParseAction(string s)
        {
            if (string.IsNullOrEmpty(s)) return ActionType.None;
            switch (s.ToLowerInvariant())
            {
                case "check":     return ActionType.Check;
                case "call":      return ActionType.Call;
                case "bet":       return ActionType.Bet;
                case "raise":     return ActionType.Raise;
                case "fold":      return ActionType.Fold;
                case "allin":
                case "all-in":    return ActionType.AllIn;
                case "bringin":   return ActionType.BringIn;
                case "straddle":  return ActionType.Straddle;
                case "discard":   return ActionType.Discard;
                case "standpat":  return ActionType.StandPat;
                default:          return ActionType.None;
            }
        }
    }
}
