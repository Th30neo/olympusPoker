using System;
using UnityEngine;

namespace Olympus.Services
{
    /// <summary>
    /// Simple timer service that supports up to three concurrent timers.
    /// Each timer invokes a callback when it expires.  Attach this
    /// component to a GameObject in your scene.
    /// </summary>
    public class TimerService : MonoBehaviour
    {
        private class Timer
        {
            public float Duration;
            public float Remaining;
            public Action Callback;
            public bool Active;
        }
        private readonly Timer[] _timers = new Timer[3];
        private void Awake()
        {
            for (int i = 0; i < _timers.Length; i++)
            {
                _timers[i] = new Timer { Active = false };
            }
        }
        private void Update()
        {
            float dt = Time.deltaTime;
            for (int i = 0; i < _timers.Length; i++)
            {
                var t = _timers[i];
                if (!t.Active) continue;
                t.Remaining -= dt;
                if (t.Remaining <= 0f)
                {
                    t.Active = false;
                    var cb = t.Callback;
                    t.Callback = null;
                    cb?.Invoke();
                }
            }
        }
        /// <summary>
        /// Starts a timer on the given index (0–2).  If a timer is already
        /// running at that index it is overwritten.
        /// </summary>
        public void StartTimer(int index, float duration, Action callback)
        {
            if (index < 0 || index >= _timers.Length) throw new ArgumentOutOfRangeException(nameof(index));
            _timers[index].Duration = duration;
            _timers[index].Remaining = duration;
            _timers[index].Callback = callback;
            _timers[index].Active = true;
        }
        /// <summary>
        /// Stops a timer.
        /// </summary>
        public void StopTimer(int index)
        {
            if (index < 0 || index >= _timers.Length) throw new ArgumentOutOfRangeException(nameof(index));
            _timers[index].Active = false;
            _timers[index].Callback = null;
        }
    }
}