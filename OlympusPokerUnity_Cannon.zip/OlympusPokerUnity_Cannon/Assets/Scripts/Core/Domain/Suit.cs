using System;

namespace Olympus.Core.Domain
{
    /// <summary>
    /// Card suits for a standard deck.  Jokers are represented separately
    /// (see Deck configuration).
    /// </summary>
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}