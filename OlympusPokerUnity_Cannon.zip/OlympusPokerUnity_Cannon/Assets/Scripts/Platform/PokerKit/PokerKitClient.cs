using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace Olympus.Platform.PokerKit
{
    /// <summary>
    /// Client wrapper for communicating with the PokerKit microservice.  To
    /// call the equity endpoint, pass hero and villain hole cards and an
    /// optional board; the response will contain win probabilities.
    /// </summary>
    public class PokerKitClient : MonoBehaviour
    {
        /// <summary>
        /// Base URL of the PokerKit service.  Change this if you host the
        /// service remotely.
        /// </summary>
        [Tooltip("Base URL of the PokerKit service (e.g. http://localhost:8089)")]
        public string baseUrl = "http://localhost:8089";

        /// <summary>
        /// Invokes the equity API.  The callback receives heroWin,
        /// villainWin, and tie probabilities when the request completes.
        /// </summary>
        public void ComputeEquity(List<string> hero, List<string> villain, List<string> board, Action<float, float, float> callback)
        {
            StartCoroutine(ComputeEquityRoutine(hero, villain, board, callback));
        }

        private IEnumerator ComputeEquityRoutine(List<string> hero, List<string> villain, List<string> board, Action<float, float, float> callback)
        {
            var payload = new EquityRequest { hero = hero, villain = villain, board = board };
            string json = JsonUtility.ToJson(payload);
            string url = $"{baseUrl}/api/v1/holdem/equity";
            using var request = new UnityWebRequest(url, "POST");
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            yield return request.SendWebRequest();
            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"PokerKit API error: {request.error}");
                callback?.Invoke(0f, 0f, 1f);
            }
            else
            {
                try
                {
                    var response = JsonUtility.FromJson<EquityResponse>(request.downloadHandler.text);
                    callback?.Invoke(response.hero_win, response.villain_win, response.tie);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"Failed to parse PokerKit response: {ex.Message}");
                    callback?.Invoke(0f, 0f, 1f);
                }
            }
        }

        [Serializable]
        private class EquityRequest
        {
            public List<string> hero;
            public List<string> villain;
            public List<string> board;
        }

        [Serializable]
        private class EquityResponse
        {
            public float hero_win;
            public float villain_win;
            public float tie;
        }
    }
}