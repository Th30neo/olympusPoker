namespace Olympus.Platform
{
    /// <summary>
    /// Interface for external platform integrations (e.g. Skillz or server back end).
    /// Implementations should translate game events to platform API calls and
    /// funnel platform events back into the game via Hermes.
    /// </summary>
    public interface IPlatformAdapter
    {
        /// <summary>
        /// Called when a match or game is ready to start.
        /// </summary>
        void OnMatchReady(string modeId);

        /// <summary>
        /// Called when the game has concluded and a result should be submitted.
        /// </summary>
        void SubmitResult(int score);

        /// <summary>
        /// Called when a fatal error occurs that requires aborting the match.
        /// </summary>
        void OnError(string message);
    }
}