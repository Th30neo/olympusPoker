using UnityEngine;
using Olympus.Libraries;
using Olympus.Gods;
using Olympus.Muses;
using Olympus.Core.Deck;

namespace Olympus.Bootstrap
{
    /// <summary>
    /// Entry point for the demonstration.  Attach this component to any
    /// GameObject to run a sample game.  It loads the specified variant,
    /// validates it, constructs the scroll, instantiates a Muse and runs
    /// the game.
    /// </summary>
    public class OlympusBootstrap : MonoBehaviour
    {
        [Tooltip("Name of the variant JSON file (without .json) in Resources/Libraries")]
        public string variantFile = "variant_holdem";

        [Tooltip("Seed for deterministic random number generation")]
        public int seed = 42;

        private void Start()
        {
            // Load libraries
            var loader = new LibraryLoader();
            // Forge scroll
            var zeus = new Zeus(loader);
            var scroll = zeus.ForgeScroll(variantFile);
            // Validate scroll
            var athena = new Athena();
            if (!athena.Validate(scroll))
            {
                Debug.LogWarning("Scroll validation failed but continuing anyway");
            }
            // Create RNG
            var apollo = new Apollo(seed);
            var rng = apollo.CreateRng();
            // Run the game via Muse
            var muse = new MuseOfGameplay(scroll, rng);
            muse.RunGame();
            // Notify platform
            Hermes.MatchReady(scroll.Id);
        }
    }
}