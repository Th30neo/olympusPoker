using System;
using System.Collections.Generic;
using UnityEngine;
using Olympus.Core.Domain;
using Olympus.Core.Deck;
using Olympus.Core.Eval;
using Olympus.Libraries;
using Olympus.Gods;

namespace Olympus.Muses
{
    /// <summary>
    /// The Muse of Gameplay receives a Scroll from Zeus, constructs the deck,
    /// deals cards, sets up the board and runs the game loop.  After the
    /// game completes it reports the result via Hermes.
    /// </summary>
    public class MuseOfGameplay
    {
        private readonly ScrollGameRules _scroll;
        private readonly ApolloRng _rng;
        private readonly List<Card> _deck;

        public MuseOfGameplay(ScrollGameRules scroll, ApolloRng rng)
        {
            _scroll = scroll;
            _rng = rng;
            // Build deck from scroll definition
            _deck = DeckBuilder.BuildDeck(_scroll.Deck.ranks, _scroll.Deck.suits, _scroll.Deck.jokers);
        }

        /// <summary>
        /// Runs a single round of the game.  Deals hole cards and board,
        /// computes equity, logs the result, and reports to Hermes.
        /// </summary>
        public void RunGame()
        {
            // Shuffle deck
            var deckArray = _deck.ToArray();
            _rng.Shuffle(deckArray);
            int index = 0;
            // Deal hero and villain hole cards
            var hero = new List<Card>();
            var villain = new List<Card>();
            for (int i = 0; i < _scroll.HoleCards; i++)
            {
                hero.Add(deckArray[index++]);
            }
            for (int i = 0; i < _scroll.HoleCards; i++)
            {
                villain.Add(deckArray[index++]);
            }
            // Deal community cards
            var board = new List<Card>();
            for (int i = 0; i < _scroll.CommunityCards; i++)
            {
                board.Add(deckArray[index++]);
            }
            // Compute equity using Monte‑Carlo approximation.  This method
            // handles different variants by accepting the hole and community
            // card counts from the scroll.  For Omaha (4 hole cards) it will
            // evaluate two‑plus‑three combinations; for standard variants
            // it performs a seven‑card evaluation.  If the variant has a
            // larger board (e.g. double flop), the evaluator will trim or pad
            // to seven cards as needed.
            var (heroEq, villainEq, tieEq) = EquityCalculator.ComputeEquityGeneral(
                hero,
                villain,
                board,
                new List<Card>(_deck),
                _rng,
                200,
                _scroll.HoleCards,
                _scroll.CommunityCards);
            Debug.Log($"Hero: {string.Join(",", hero)} - Villain: {string.Join(",", villain)} - Board: {string.Join(",", board)}");
            Debug.Log($"Equity -> Hero: {heroEq:P1}, Villain: {villainEq:P1}, Tie: {tieEq:P1}");
            // Determine winner for demonstration
            string winner;
            if (heroEq > villainEq) winner = "Hero wins";
            else if (villainEq > heroEq) winner = "Villain wins";
            else winner = "Tie";
            Debug.Log($"Winner: {winner}");
            // Submit a dummy score: 1 for hero, 0 for villain, 0.5 for tie
            int score = heroEq > villainEq ? 1 : villainEq > heroEq ? -1 : 0;
            Hermes.SubmitResult(score);
        }
    }
}