using System;
using System.Collections.Generic;
using Olympus.Core.Domain;

namespace Olympus.Core.Eval
{
    /// <summary>
    /// Evaluates five‑card and seven‑card poker hands.  The evaluator uses
    /// exhaustive enumeration for seven‑card hands: it evaluates all
    /// 21 combinations of 5 out of 7 cards and selects the best.
    /// </summary>
    public static class HandEvaluator
    {
        /// <summary>
        /// Evaluates the best hand rank and high cards of a seven‑card hand.
        /// </summary>
        /// <param name="cards">A list of exactly seven cards.</param>
        /// <returns>A tuple containing the hand rank and a sorted list of ranks for comparison.</returns>
        public static (HandRank rank, List<Rank> highCards) Evaluate7(List<Card> cards)
        {
            if (cards == null || cards.Count != 7)
            {
                throw new ArgumentException("Seven cards are required for evaluation");
            }
            HandRank bestRank = HandRank.HighCard;
            List<Rank> bestHighCards = new List<Rank>();
            // Enumerate all 5‑card combinations
            var idx = new int[5];
            for (idx[0] = 0; idx[0] < 7 - 4; idx[0]++)
            for (idx[1] = idx[0] + 1; idx[1] < 7 - 3; idx[1]++)
            for (idx[2] = idx[1] + 1; idx[2] < 7 - 2; idx[2]++)
            for (idx[3] = idx[2] + 1; idx[3] < 7 - 1; idx[3]++)
            for (idx[4] = idx[3] + 1; idx[4] < 7; idx[4]++)
            {
                var five = new List<Card>(5);
                for (int i = 0; i < 5; i++)
                    five.Add(cards[idx[i]]);
                var (rank, high) = Evaluate5(five);
                if (CompareHands(rank, high, bestRank, bestHighCards) > 0)
                {
                    bestRank = rank;
                    bestHighCards = high;
                }
            }
            return (bestRank, bestHighCards);
        }

        /// <summary>
        /// Evaluates a five‑card poker hand.
        /// </summary>
        /// <summary>
        /// Evaluates a five‑card poker hand.  This method is public so
        /// extension methods (e.g. Omaha evaluation) can reuse the core
        /// five‑card logic.
        /// </summary>
        public static (HandRank, List<Rank>) Evaluate5(List<Card> cards)
        {
            // Count occurrences of ranks and suits
            var rankCounts = new Dictionary<Rank, int>();
            var suitCounts = new Dictionary<Suit, int>();
            foreach (var card in cards)
            {
                if (!rankCounts.ContainsKey(card.Rank)) rankCounts[card.Rank] = 0;
                rankCounts[card.Rank]++;
                if (!suitCounts.ContainsKey(card.Suit)) suitCounts[card.Suit] = 0;
                suitCounts[card.Suit]++;
            }
            bool isFlush = false;
            Suit flushSuit = Suit.Clubs;
            foreach (var kv in suitCounts)
            {
                if (kv.Value == 5)
                {
                    isFlush = true;
                    flushSuit = kv.Key;
                    break;
                }
            }
            // Prepare sorted rank list for comparisons
            var orderedRanks = new List<Rank>(cards.Count);
            foreach (var card in cards) orderedRanks.Add(card.Rank);
            orderedRanks.Sort((a,b) => ((int)b).CompareTo((int)a));
            // Straight detection (with ace low)
            bool isStraight = false;
            List<Rank> straightRanks = new List<Rank>();
            var distinctRanks = new List<Rank>(new HashSet<Rank>(orderedRanks));
            distinctRanks.Sort((a, b) => ((int)b).CompareTo((int)a));
            // Check high‑ace straight
            if (distinctRanks.Count >= 5)
            {
                for (int i = 0; i <= distinctRanks.Count - 5; i++)
                {
                    int high = (int)distinctRanks[i];
                    bool run = true;
                    for (int j = 1; j < 5; j++)
                    {
                        if ((int)distinctRanks[i + j] != high - j)
                        {
                            run = false;
                            break;
                        }
                    }
                    if (run)
                    {
                        isStraight = true;
                        straightRanks = new List<Rank> { distinctRanks[i] };
                        break;
                    }
                }
            }
            // Check wheel (A‑5 straight)
            if (!isStraight)
            {
                if (distinctRanks.Contains(Rank.Ace) && distinctRanks.Contains(Rank.Five) && distinctRanks.Contains(Rank.Four) && distinctRanks.Contains(Rank.Three) && distinctRanks.Contains(Rank.Two))
                {
                    isStraight = true;
                    straightRanks = new List<Rank> { Rank.Five };
                }
            }
            // Determine rank counts for four/three/pairs
            int maxCount = 0;
            int secondMax = 0;
            Rank maxRank = Rank.Ace;
            Rank secondRank = Rank.Ace;
            foreach (var kv in rankCounts)
            {
                if (kv.Value > maxCount || (kv.Value == maxCount && kv.Key > maxRank))
                {
                    secondMax = maxCount;
                    secondRank = maxRank;
                    maxCount = kv.Value;
                    maxRank = kv.Key;
                }
                else if (kv.Value > secondMax || (kv.Value == secondMax && kv.Key > secondRank))
                {
                    secondMax = kv.Value;
                    secondRank = kv.Key;
                }
            }
            HandRank handRank;
            List<Rank> highCards = new List<Rank>();
            if (isFlush && isStraight)
            {
                handRank = HandRank.StraightFlush;
                highCards = straightRanks;
            }
            else if (maxCount == 4)
            {
                handRank = HandRank.FourOfAKind;
                highCards.Add(maxRank);
                foreach (var r in orderedRanks)
                {
                    if (r != maxRank)
                    {
                        highCards.Add(r);
                        break;
                    }
                }
            }
            else if (maxCount == 3 && secondMax == 2)
            {
                handRank = HandRank.FullHouse;
                highCards.Add(maxRank);
                highCards.Add(secondRank);
            }
            else if (isFlush)
            {
                handRank = HandRank.Flush;
                highCards = orderedRanks;
            }
            else if (isStraight)
            {
                handRank = HandRank.Straight;
                highCards = straightRanks;
            }
            else if (maxCount == 3)
            {
                handRank = HandRank.ThreeOfAKind;
                highCards.Add(maxRank);
                foreach (var r in orderedRanks)
                {
                    if (r != maxRank) highCards.Add(r);
                }
            }
            else if (maxCount == 2 && secondMax == 2)
            {
                handRank = HandRank.TwoPair;
                // Determine which pair is higher
                Rank highPair = maxRank >= secondRank ? maxRank : secondRank;
                Rank lowPair = maxRank >= secondRank ? secondRank : maxRank;
                highCards.Add(highPair);
                highCards.Add(lowPair);
                foreach (var r in orderedRanks)
                {
                    if (r != highPair && r != lowPair)
                    {
                        highCards.Add(r);
                        break;
                    }
                }
            }
            else if (maxCount == 2)
            {
                handRank = HandRank.OnePair;
                highCards.Add(maxRank);
                foreach (var r in orderedRanks)
                {
                    if (r != maxRank) highCards.Add(r);
                }
            }
            else
            {
                handRank = HandRank.HighCard;
                highCards = orderedRanks;
            }
            return (handRank, highCards);
        }

        /// <summary>
        /// Compares two hands by hand rank and high cards.  Returns 1 if
        /// (rankA, highA) is better than (rankB, highB), -1 if worse, or 0 if tie.
        /// </summary>
        private static int CompareHands(HandRank rankA, List<Rank> highA, HandRank rankB, List<Rank> highB)
        {
            if (rankA > rankB) return 1;
            if (rankA < rankB) return -1;
            int n = Math.Min(highA.Count, highB.Count);
            for (int i = 0; i < n; i++)
            {
                if (highA[i] > highB[i]) return 1;
                if (highA[i] < highB[i]) return -1;
            }
            return 0;
        }
    }
}