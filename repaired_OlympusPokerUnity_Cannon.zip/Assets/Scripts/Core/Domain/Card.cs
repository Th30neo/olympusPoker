using System;

namespace Olympus.Core.Domain
{
    /// <summary>
    /// Represents a playing card.  Jokers are represented by setting
    /// <see cref="IsJoker"/> to <c>true</c> and leaving rank/suit undefined.
    /// </summary>
    public struct Card : IComparable<Card>
    {
        public Rank Rank { get; }
        public Suit Suit { get; }
        public bool IsJoker { get; }

        public Card(Rank rank, Suit suit)
        {
            Rank = rank;
            Suit = suit;
            IsJoker = false;
        }

        public Card(bool joker)
        {
            Rank = Rank.Ace;
            Suit = Suit.Spades;
            IsJoker = joker;
        }

        public override string ToString()
        {
            if (IsJoker)
            {
                return "Joker";
            }
            string rankString = Rank switch
            {
                Rank.Two => "2",
                Rank.Three => "3",
                Rank.Four => "4",
                Rank.Five => "5",
                Rank.Six => "6",
                Rank.Seven => "7",
                Rank.Eight => "8",
                Rank.Nine => "9",
                Rank.Ten => "T",
                Rank.Jack => "J",
                Rank.Queen => "Q",
                Rank.King => "K",
                Rank.Ace => "A",
                _ => "?"
            };
            char suitChar = Suit switch
            {
                Suit.Clubs => 'c',
                Suit.Diamonds => 'd',
                Suit.Hearts => 'h',
                Suit.Spades => 's',
                _ => '?'
            };
            return rankString + suitChar;
        }

        public int CompareTo(Card other)
        {
            if (IsJoker && other.IsJoker) return 0;
            if (IsJoker) return 1;
            if (other.IsJoker) return -1;
            int rankComparison = Rank.CompareTo(other.Rank);
            return rankComparison != 0 ? rankComparison : Suit.CompareTo(other.Suit);
        }
    }
}