using System;

namespace Olympus.Core.Deck
{
    /// <summary>
    /// ApolloRng wraps <see cref="System.Random"/> to provide a seeded random
    /// number generator.  Seeding via a fixed value ensures deterministic
    /// gameplay (useful for replays and fairness).
    /// </summary>
    public class ApolloRng
    {
        private readonly Random _random;

        public ApolloRng(int seed)
        {
            _random = new Random(seed);
        }

        /// <summary>
        /// Returns a random integer from 0 (inclusive) to max (exclusive).
        /// </summary>
        public int Next(int max)
        {
            return _random.Next(max);
        }

        /// <summary>
        /// Shuffles an array in place using the Fisher–Yates algorithm.
        /// </summary>
        public void Shuffle<T>(T[] array)
        {
            for (int i = array.Length - 1; i > 0; i--)
            {
                int j = _random.Next(i + 1);
                (array[i], array[j]) = (array[j], array[i]);
            }
        }
    }
}