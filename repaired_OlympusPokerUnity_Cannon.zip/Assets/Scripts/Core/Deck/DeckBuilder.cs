using System;
using System.Collections.Generic;
using Olympus.Core.Domain;

namespace Olympus.Core.Deck
{
    /// <summary>
    /// Builds card decks according to configurations loaded from JSON.
    /// </summary>
    public static class DeckBuilder
    {
        /// <summary>
        /// Creates a list of cards given rank and suit identifiers and a joker count.
        /// </summary>
        /// <param name="ranks">List of rank strings (e.g. "A", "K", "Q").</param>
        /// <param name="suits">List of suit characters (c, d, h, s).</param>
        /// <param name="jokers">Number of jokers to include.</param>
        public static List<Card> BuildDeck(List<string> ranks, List<string> suits, int jokers)
        {
            var deck = new List<Card>();
            foreach (string r in ranks)
            {
                Rank rank = ParseRank(r);
                foreach (string s in suits)
                {
                    Suit suit = ParseSuit(s);
                    deck.Add(new Card(rank, suit));
                }
            }
            for (int i = 0; i < jokers; i++)
            {
                deck.Add(new Card(true));
            }
            return deck;
        }

        private static Rank ParseRank(string r)
        {
            return r.ToUpper() switch
            {
                "2" => Rank.Two,
                "3" => Rank.Three,
                "4" => Rank.Four,
                "5" => Rank.Five,
                "6" => Rank.Six,
                "7" => Rank.Seven,
                "8" => Rank.Eight,
                "9" => Rank.Nine,
                "T" => Rank.Ten,
                "J" => Rank.Jack,
                "Q" => Rank.Queen,
                "K" => Rank.King,
                "A" => Rank.Ace,
                _ => throw new ArgumentException($"Unknown rank: {r}")
            };
        }

        private static Suit ParseSuit(string s)
        {
            return s.ToLower() switch
            {
                "c" => Suit.Clubs,
                "d" => Suit.Diamonds,
                "h" => Suit.Hearts,
                "s" => Suit.Spades,
                _ => throw new ArgumentException($"Unknown suit: {s}")
            };
        }
    }
}