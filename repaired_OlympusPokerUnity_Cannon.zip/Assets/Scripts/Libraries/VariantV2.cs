using System;
using System.Collections.Generic;
using UnityEngine;

namespace Olympus.Libraries
{
    [Serializable] public class VariantV2Root { public VariantV2 variant; }

    [Serializable]
    public class VariantV2
    {
        public string id;
        public string label;
        public string deck;          // Standard52 / Standard54Jokers / ShortDeck36
        public string board;         // Community0/3/4/5/DoubleFlop10
        public string betting;       // NoLimit / PotLimit / FixedLimit
        public Seats seats;
        public List<string> actions;
        public int holeCards;
        public int communityCards;
        public int timers;           // 0..3
        public bool jokersWild;
        public Positions positions;
        public List<Phase> phases;   // v2 addition
        public string notes;
    }

    [Serializable] public class Seats { public int min; public int max; }
    [Serializable] public class Positions { public string rotation; public int seatingMax; }

    [Serializable]
    public class Phase
    {
        public string id;
        public string label;
        public string kind;          // Setup/Deal/Passing/Reveal/Betting/Draw/Showdown/Cleanup/Custom
        public List<string> actions;
        public List<string> transitions;
        public List<string> timers;  // Turn/Street/Match
        public int boardReveal;      // for Reveal
        public Pass pass;            // for Passing
        public Deal deal;            // for Deal
    }

    [Serializable] public class Pass { public string direction; public int count; }
    [Serializable] public class Deal { public int holePerPlayer; public int burn; }
}
