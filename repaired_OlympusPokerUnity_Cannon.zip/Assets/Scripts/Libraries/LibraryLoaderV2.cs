// Assets/Scripts/Libraries/LibraryLoaderV2.cs
using System.Collections.Generic;
using UnityEngine;

namespace Olympus.Libraries
{
    /// <summary>
    /// Loads a V2 json and converts to ScrollGameRules understood by the rest of the engine.
    /// </summary>
    public static class LibraryLoaderV2
    {
        /// <summary>
        /// Load a JSON TextAsset from Resources/Libraries without the ".json" suffix.
        /// Ex: "v2/variant_doubleflop_holdem_v2"
        /// </summary>
        public static T LoadJson<T>(string relativePathOrFile)
        {
            // Accept either "v2/foo.json" or "v2/foo"
            var path = relativePathOrFile.Trim();
            if (path.EndsWith(".json")) path = path.Substring(0, path.Length - 5);

            var ta = Resources.Load<TextAsset>($"Libraries/{path}");
            if (ta == null)
            {
                Debug.LogError($"LibraryLoaderV2: Resources/Libraries/{path}.json not found");
                return default;
            }
            return JsonUtility.FromJson<T>(ta.text);
        }

        /// <summary>
        /// Convert V2 DTOs into a ScrollGameRules instance.
        /// </summary>
        public static ScrollGameRules ToScroll(VariantV2 v)
        {
            var scroll = new ScrollGameRules();

            // Identity / variant naming
            var variantId = !string.IsNullOrEmpty(v.id) ? v.id : (v.name ?? "variant_v2");
            scroll.Id = variantId;
            scroll.Variant = !string.IsNullOrEmpty(v.family) ? v.family : v.name;

            // Seats
            if (v.seats != null)
            {
                scroll.SeatsMin = v.seats.min <= 0 ? 2 : v.seats.min;
                scroll.SeatsMax = v.seats.max <= 0 ? 2 : v.seats.max;
            }

            // Deck
            if (v.deck != null)
            {
                scroll.Deck = SchemaMaps.ParseDeckKind(v.deck.kind);
                // prefer explicit toggle, fallback to deck.jokers
                scroll.JokersWild = (v.toggles != null && v.toggles.jokersWild) || v.deck.jokers;
            }

            // Board
            if (v.board != null)
            {
                scroll.BoardLayout = SchemaMaps.ParseBoardLayout(v.board.layout);
            }

            // Betting
            if (v.betting != null)
            {
                scroll.Betting = SchemaMaps.ParseBettingStyle(v.betting.style);
            }

            // Actions
            scroll.AllowedActions = new List<ActionType>();
            if (v.actions != null && v.actions.allow != null)
            {
                foreach (var a in v.actions.allow)
                {
                    var parsed = SchemaMaps.ParseAction(a);
                    if (parsed != ActionType.None && !scroll.AllowedActions.Contains(parsed))
                        scroll.AllowedActions.Add(parsed);
                }
            }
            if (scroll.AllowedActions.Count == 0)
            {
                // safe default for HU poker
                scroll.AllowedActions.AddRange(new[]
                {
                    ActionType.Check, ActionType.Call, ActionType.Bet, ActionType.Raise, ActionType.Fold, ActionType.AllIn
                });
            }

            // Timers
            if (v.timers != null) scroll.TimersCount = v.timers.count;

            return scroll;
        }

        /// <summary>
        /// Shortcut: load a V2 json path and return a Scroll.
        /// Accepts "v2/variant_xxx.json" or "v2/variant_xxx".
        /// </summary>
        public static ScrollGameRules LoadScroll(string v2Path)
        {
            var root = LoadJson<VariantV2Root>(v2Path);
            if (root == null || root.variant == null)
            {
                Debug.LogError($"LibraryLoaderV2: variant missing in {v2Path}");
                return new ScrollGameRules { Id = "invalid_v2", Variant = "invalid" };
            }
            return ToScroll(root.variant);
        }
    }
}
