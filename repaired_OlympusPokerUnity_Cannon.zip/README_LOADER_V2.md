# Cannon LibraryLoaderV2 (with Phase Control + Validator)

Drop these into your Unity project (recommended path: `Assets/`).
Requires built‑in packages: **JSON Serialize**, **Unity UI (UGUI)** if you use the HUD.

**What you get**
- `Assets/Scripts/Libraries/VariantV2.cs` — data classes for v2 schema (with phases).
- `Assets/Scripts/Libraries/VariantValidator.cs` — structural validator (no external deps).
- `Assets/Scripts/Libraries/LibraryLoaderV2.cs` — loads/validates JSON from `Resources/Libraries`.
- `Assets/Resources/Libraries/v2/*.json` — ready‑made variants: Double‑Flop Hold’em, Stud, Baseball.
- `Assets/Resources/Libraries/actions.json`, `boards.json`, `decks.json`, `betting.json` — canonical libraries.

**How to use**
1. Enable **JSON Serialize** in Package Manager → Built‑in.
2. Put the JSON files under `Assets/Resources/Libraries/`.
3. Load a variant:
   ```csharp
   var v = Olympus.Libraries.LibraryLoaderV2.LoadVariant("v2/variant_doubleflop_holdem_v2");
   var errors = Olympus.Libraries.VariantValidator.Validate(v);
   if (errors.Count > 0) Debug.LogError(string.Join("\n", errors));
   ```
4. (Optional) Convert to your `ScrollGameRules`:
   ```csharp
   var scroll = Olympus.Libraries.LibraryLoaderV2.ToScroll(v);
   ```
