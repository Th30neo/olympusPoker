
# Cannon Schema v2 (with PHASE control)

**What this is:** A drop-in library pack that adds *explicit phase control* to your variant schemas.

- `schema/variant.schema.json` — JSON Schema (Draft-07) requiring a `phases` array per variant.
- `libraries/*.json` — canonical lists (actions, betting styles, decks, boards).
- `current/*.json` — the exact variants you provided (without phases), copied verbatim.
- `v2/*.json` — upgraded variants **with phases** for Hold'em and Anaconda.

## How to use

1. Put these JSON files in your Unity project's `Assets/Resources/Libraries/` (or wherever your loader reads from).
2. Update the loader to validate against `schema/variant.schema.json` (optional but recommended).
3. Your runtime can drive the game loop by following each variant's `phases[*].kind`, honoring `actions` allowed per phase, and using:
   - `deal.holePerPlayer` for initial hole dealing,
   - `boardReveal` for staged community cards,
   - `pass.direction/count` for Anaconda-style passing,
   - `timers` for which timers must be active in that phase.

## Notes

- The `actions` library contains both free-size `raise` and preset `raise_xN` options.
- Add more phases (e.g., `Draw`) as needed. The schema already supports it.
